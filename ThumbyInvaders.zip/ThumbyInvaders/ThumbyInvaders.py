import thumby
import random

# ====================
# GAME STATE
# ====================
GAME_PLAYING = 0
GAME_OVER = 1
GAME_WIN = 2
game_state = GAME_PLAYING

# ====================
# BUNKERS (SOLID)
# ====================
BUNKER_W = 8
BUNKER_H = 8   # MUST be 8 for emulator

bunker_bitmap = bytearray([
    0b00011111,
    0b00111111,
    0b01111111,
    0b01111111,
    0b01111111,
    0b00111111,
    0b00011111,
    0b00000000,  # empty bottom row
])


bunkers = []

BUNKER_Y = 26
BUNKER_START_X = 10
BUNKER_SPACING = 16

def create_bunkers():
    bunkers.clear()
    for i in range(4):
        bunker = thumby.Sprite(BUNKER_W, BUNKER_H, bytearray(bunker_bitmap))
        bunker.x = BUNKER_START_X + i * BUNKER_SPACING
        bunker.y = BUNKER_Y
        bunkers.append(bunker)

# ====================
# ALIENS
# ====================
ALIEN_W = 5
ALIEN_H = 5
alien_bitmap = bytearray([30, 11, 30, 11, 30])
aliens = []

ROWS = 3
COLS = 6
START_X = 8
START_Y = 4
X_SPACING = 10
Y_SPACING = 6

def create_aliens():
    aliens.clear()
    for r in range(ROWS):
        for c in range(COLS):
            alien = thumby.Sprite(ALIEN_W, ALIEN_H, bytearray(alien_bitmap))
            alien.x = START_X + c * X_SPACING
            alien.y = START_Y + r * Y_SPACING
            aliens.append(alien)

alien_speed = 1
direction = 1
alien_move_delay = 12
alien_frame_counter = 0

def move_aliens():
    global direction
    for alien in aliens:
        if direction == 1 and alien.x + alien.width >= 72:
            direction = -1
            break
        if direction == -1 and alien.x <= 0:
            direction = 1
            break
    for alien in aliens:
        alien.x += alien_speed * direction

# ====================
# PLAYER
# ====================
player = thumby.Sprite(8, 8, bytearray([0,192,240,248,248,240,192,0]))
player.x = 32
player.y = 32
player_speed = 1

# ====================
# BULLETS
# ====================
player_bullet = thumby.Sprite(1, 3, bytearray([7]))
alien_bullet = thumby.Sprite(1, 3, bytearray([7]))

bullet_active = False
alien_bullet_active = False

bullet_speed = 2
alien_bullet_speed = 1

alien_fire_delay = 45
alien_fire_timer = 0

# ====================
# COLLISIONS
# ====================
def bullet_hits_bunker(x, y):
    for bunker in bunkers:
        if (x >= bunker.x and x < bunker.x + bunker.width and
            y >= bunker.y and y < bunker.y + bunker.height):
            return True
    return False

def bullet_hits_alien():
    global bullet_active
    for alien in aliens:
        if (player_bullet.x >= alien.x and
            player_bullet.x < alien.x + alien.width and
            player_bullet.y >= alien.y and
            player_bullet.y < alien.y + alien.height):
            aliens.remove(alien)
            bullet_active = False
            return

def alien_bullet_hits_player():
    global game_state, alien_bullet_active
    if (alien_bullet.x >= player.x and
        alien_bullet.x < player.x + player.width and
        alien_bullet.y >= player.y and
        alien_bullet.y < player.y + player.height):
        alien_bullet_active = False
        game_state = GAME_OVER

# ====================
# GAME CONTROL
# ====================
def reset_game():
    global game_state, bullet_active, alien_bullet_active
    create_aliens()
    create_bunkers()
    bullet_active = False
    alien_bullet_active = False
    game_state = GAME_PLAYING

def draw_game_over():
    thumby.display.fill(0)
    thumby.display.drawText("GAME", 22, 6, 1)
    thumby.display.drawText("OVER", 22, 16, 1)
    thumby.display.drawText("A=RESTART", 4, 28, 1)
    thumby.display.update()
    if thumby.buttonA.justPressed():
        reset_game()

def draw_win_screen():
    thumby.display.fill(0)
    thumby.display.drawText("YOU", 26, 8, 1)
    thumby.display.drawText("WIN!", 22, 18, 1)
    thumby.display.drawText("A=RESTART", 4, 30, 1)
    thumby.display.update()
    if thumby.buttonA.justPressed():
        reset_game()

# ====================
# INIT
# ====================
create_aliens()
create_bunkers()
thumby.display.setFPS(60)

# ====================
# MAIN LOOP
# ====================
while True:

    if game_state == GAME_PLAYING:

        if not aliens:
            game_state = GAME_WIN

        alien_frame_counter += 1
        if alien_frame_counter >= alien_move_delay:
            move_aliens()
            alien_frame_counter = 0

        alien_fire_timer += 1
        if alien_fire_timer >= alien_fire_delay and not alien_bullet_active and aliens:
            shooter = random.choice(aliens)
            alien_bullet.x = shooter.x + shooter.width // 2
            alien_bullet.y = shooter.y + shooter.height
            alien_bullet_active = True
            alien_fire_timer = 0

        if alien_bullet_active:
            alien_bullet.y += alien_bullet_speed
            if bullet_hits_bunker(alien_bullet.x, alien_bullet.y):
                alien_bullet_active = False
            alien_bullet_hits_player()
            if alien_bullet.y > 40:
                alien_bullet_active = False

        if thumby.buttonL.pressed():
            player.x -= player_speed
        if thumby.buttonR.pressed():
            player.x += player_speed
        player.x = max(0, min(player.x, 72 - player.width))

        if thumby.buttonA.justPressed() and not bullet_active:
            player_bullet.x = player.x + player.width // 2
            player_bullet.y = player.y
            bullet_active = True

        if bullet_active:
            player_bullet.y -= bullet_speed
            if bullet_hits_bunker(player_bullet.x, player_bullet.y):
                bullet_active = False
            bullet_hits_alien()
            if player_bullet.y < 0:
                bullet_active = False

        thumby.display.fill(0)
        thumby.display.drawSprite(player)
        for bunker in bunkers:
            thumby.display.drawSprite(bunker)
        for alien in aliens:
            thumby.display.drawSprite(alien)
        if bullet_active:
            thumby.display.drawSprite(player_bullet)
        if alien_bullet_active:
            thumby.display.drawSprite(alien_bullet)
        thumby.display.update()

    elif game_state == GAME_OVER:
        draw_game_over()
    else:
        draw_win_screen()




    
        