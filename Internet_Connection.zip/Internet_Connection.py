#### !!!! BLOCKLY EXPORT !!!! ####
from thumbyGraphics import display
import time
import thumbyButton as buttons
import machine

def __print_to_display__(message):
      message = str(message)
      display.fill(0)
      txt = [""]
      for line in message.split("\n"):
          for word in line.split(" "):
              next_len = len(txt[-1]) + len(word) + 1
              if next_len*display.textWidth + (next_len-1) > display.width:
                  txt += [""]
              txt[-1] += (" " if txt[-1] else "") + word
          txt += [""]
      for ln, line in enumerate(txt):
          display.drawText(line, 0, (display.textHeight+1)*ln, 1)
      display.display.show()



__print_to_display__('Internet Connection:')
time.sleep(2)
while not buttons.buttonA.justPressed():
  __print_to_display__('Press A to Connect')
__print_to_display__('Connected!')
time.sleep(3)
while not buttons.buttonB.justPressed():
  __print_to_display__('Press B to Disconnect')
__print_to_display__('Disconnected')
time.sleep(3)
machine.reset()

#### !!!! BLOCKLY EXPORT !!!! ####